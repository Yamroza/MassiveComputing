For this assignment 2 files are uploaded (html and ipynb) in order to see visualised scatter plots in html file.
