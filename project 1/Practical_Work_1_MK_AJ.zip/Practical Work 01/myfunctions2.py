
# import necessary libraries and modules
import numpy as np
from myfunctions import tonumpyarray

# initialization of pooling filter 
def pool_init(shared_array_, srcimg, filter_mask):
    """
    Initialize the global shared memory data shared_array_ - shared read/write data, with lock. 
    It is a vector (because the shared memory should be allocated as a vector)
    srcimg - the original image
    filtermask - filter which will be applied to the image 
    Results will be stored in the shared memory array.
    """
    
    # declare the global variables 
    global shared_space         # define the local process memory reference for shared memory space
    global image                # define the read-only memory data as global (the scope of this global variables is the local module). Placeholder for our input image. 
    global my_filter            # define the variable that will hold the filter mask that we will apply on our image
    global shared_matrix        # define the numpy matrix handler
    
    
    # initialize the global read only memory data
    image = srcimg
    my_filter = filter_mask
    size = image.shape # calculate how much space should be allocated for each pixel in our output image

    shared_space = shared_array_    # assign the shared memory to the local reference
    shared_matrix = tonumpyarray(shared_space).reshape(size)    # define the numpy matrix reference to handle data, which will use the shared memory buffer. Create a new matrix with dimensions equal to those of our input image, then reshape it

# define the filtering function
def filtering(r):
    """
    Use global variables to filter the specific row of the image.
    Overwrite the shared matrix containing the results of the calculae, while using lock to avoid races.
    r = row number
    """
    
    
    # declare the global variables 
    global image
    global my_filter
    global shared_space
    global shared_matrix

    # define image and filter shapes
    (rows, cols, depth) = image.shape
    (filter_rows, filter_cols) = my_filter.shape

    # get the row from the original image
    srow = image[r,:,:]

    # define the results vector and set the initial value to 0
    frow = np.zeros((cols,depth))

    # calculate how many rows & columns we have to take
    additional_rows_number = int((filter_rows - 1) / 2)
    additional_cols_number = int((filter_cols - 1) / 2)    
    
    
    for i in range(len(srow)):      # iterate on the pixels in the row, then through each column
        for j in range(depth):      # iterate on the colour components (1 for grayscale, 3 for color)
            sum = 0                 # final pixel value
            for row in range(filter_rows):
                for col in range(filter_cols):

                    row_position = r + row - additional_rows_number
                    if row_position < 0:
                        row_position = 0
                    if row_position > len(image)-1:
                        row_position = len(image)-1

                    col_position = i + col - additional_cols_number
                    if col_position < 0:
                        sum += my_filter[row][col] * image[row_position,:,:][0][j]
                    elif col_position > len(srow) - 1:
                        sum += my_filter[row][col] * image[row_position,:,:][-1][j]
                    else:
                        sum += my_filter[row][col] * image[row_position,:,:][col_position][j]

            frow[i][j] = sum

    with shared_space.get_lock():
        shared_matrix[r,:,:] = frow

    return


# This cell should be the last one to avoid the execution of 
# this script when is invoked directly.
if __name__ == "__main__":
    print("This is not an executable library") 
